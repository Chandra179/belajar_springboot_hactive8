package assesment1_Chandra_JVSB001ONL010;

public class PerbandinganTrueFalse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 8;
		int c = 12;
		int d = 5;
		
		System.out.println("Tes ke 1 = " + (a > b));
		System.out.println("Tes ke 2 = " + (b < a));
		System.out.println("Tes ke 3 = " + (a >= b));
		System.out.println("Tes ke 4 = " + (b <= a));
		System.out.println("Tes ke 5 = " + (d == a / 2));
		System.out.println("Tes ke 6 = " + (a != b));
		System.out.println("Tes ke 7 = " + (b > a));
		System.out.println("Tes ke 8 = " + (a <= b));
		System.out.println("Tes ke 9 = " + (a == b));
		System.out.println("Tes ke 10 = " + (d != a / 2));
	}

}
