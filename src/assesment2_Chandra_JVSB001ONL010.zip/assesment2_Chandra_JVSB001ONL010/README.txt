ROOT CLASS UNTUK RUN PROGRAM
--------------------------------------
Latihan_1
Latihan_2
Latihan_3
Latihan_4
Latihan_5

---------------------------------------
Stream            -> aliran data
String.format     -> digunakan untuk penambahan format-format tertentu pada string, 
 		     contoh : %10s spasi 10x untuk format string
List<String>      -> koleksi string dengan tipe data List
ArrayList<String> -> array dengan tipe data string, merupakan child List<>
NumberFormat      -> digunakan untuk melakukan formatting dan parsing pada angka
Year library      -> tahun dalam ISO-8601 kalendar
Inheritance       -> pewarisan atribut parent class kepada child class
Polymorphism      -> method dengan nama yang sama dengan parameter yang berbeda (Overloading)
Overriding        -> overriding adalah sebuah situasi dimana method class 
                     turunan menimpa method milik parent class. Atau override method interface
Abstraction       -> digunakan untuk menghilangkan atau menghapus karakteristik 
                     dari suatu objek agar mengurangi kompleksitasnya
Encapsulation     -> metode untuk mengatur struktur class dengan 
                     cara menyembunyikan alur kerja dari class tersebut, cth: private accessor

getCurrencyInstanceNumberFormat -> format angka dalam bentuk currency/uang. Default:locale