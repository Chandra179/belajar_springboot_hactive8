package sesi_05;

public class AnakUmur1Tahun extends Induk implements InterfaceAnakUmur1Tahun {

	@Override
	public void anakSiapa() {
		// TODO Auto-generated method stub
		System.out.println("Nama anaknya adalah : " + namaAnak);
	}

	@Override
	public void hobiAnak() {
		// TODO Auto-generated method stub
		System.out.println("Hobi anaknya adalah : " + hobiAnak);
	}

}
