package sesi_05;

public interface BangunDatar {
	float luas();
	float keliling();
}
