package sesi_05;

public class Induk {
	public String namaAnak = "Chandra";
	public String hobiAnak = "Tidur";

	public void makan() {
		System.out.println("Lagi makan sate");
	}

	public void minum() {
		System.out.println("Lagi minum kopi");
	}
}
