package sesi_05;

public interface InterfaceAnakUmur1Tahun {
	void anakSiapa();

	void hobiAnak();
}
